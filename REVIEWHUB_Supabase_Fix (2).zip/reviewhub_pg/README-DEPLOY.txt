REVIEWHUB — SUPABASE DATABASE FIX

This update moves user accounts, saved reviewers, and login sessions from Render's temporary local SQLite file to Supabase PostgreSQL.

FILES TO REPLACE IN YOUR EXISTING GITHUB REPOSITORY
- server.cpp
- Dockerfile
Keep your existing index.html and other website files.

IMPORTANT BEFORE DEPLOYING
1. In Supabase, use the Session pooler connection string (URI format), if available.
2. In Render, open your existing REVIEWHUB Web Service.
3. Open Environment and add:
   Key: DATABASE_URL
   Value: paste your Supabase connection URI
4. Save changes. Do not put the URI in GitHub, server.cpp, or index.html.
5. Commit and push the replacement server.cpp and Dockerfile to the same GitHub repository. Render should deploy automatically.
6. Wait for the deploy to finish, then open the website and create a test account.
7. Log out, log in again, then refresh the page. Confirm your account and saved reviewers still load.

SECURITY
- Never share DATABASE_URL or the database password in chat or screenshots.
- If the URI contains [YOUR-PASSWORD], replace that placeholder locally with your database password.
- Do not delete the Supabase project.

NOTES
- This code creates its own tables named rh_users, rh_topics, and rh_sessions in the Supabase database. It does not modify other tables.
- Existing accounts in the old Render SQLite database are not automatically migrated. If that old database is inaccessible, users may need to register once again after deployment.
- This is a code update; persistence is not fixed until DATABASE_URL is configured and the new deployment succeeds.
